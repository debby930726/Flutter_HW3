import 'dart:async';
import 'dart:math';
import 'package:flutter/material.dart';

void main() => runApp(const MyApp());

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return const MaterialApp(
      title: '反應速度遊戲',
      debugShowCheckedModeBanner: false,
      home: GameRoot(),
    );
  }
}

// ── Lifting State Up：管理全局狀態 ──

class GameRoot extends StatefulWidget {
  const GameRoot({super.key});
  @override
  State<GameRoot> createState() => _GameRootState();
}

class _GameRootState extends State<GameRoot> {
  int _dotCount = 3;
  List<int> _reactionTimes = []; // ms，-1 代表失敗
  bool _gameActive = false;
  static const int totalRounds = 10;

  void _onStart(int dotCount) {
    setState(() {
      _dotCount = dotCount;
      _reactionTimes = [];
      _gameActive = true;
    });
  }

  void _onRoundDone(int ms) {
    setState(() => _reactionTimes.add(ms));
  }

  void _onGameOver() {
    setState(() => _gameActive = false);
  }

  void _onRestart() {
    setState(() {
      _reactionTimes = [];
      _gameActive = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    if (!_gameActive && _reactionTimes.isEmpty) {
      return SetupScreen(onStart: _onStart);
    } else if (_gameActive) {
      return GameScreen(
        dotCount: _dotCount,
        totalRounds: totalRounds,
        onRoundDone: _onRoundDone,
        onGameOver: _onGameOver,
      );
    } else {
      return ResultScreen(
        reactionTimes: _reactionTimes,
        onRestart: _onRestart,
      );
    }
  }
}

// ── 設定頁 ──

class SetupScreen extends StatefulWidget {
  final void Function(int dotCount) onStart;
  const SetupScreen({super.key, required this.onStart});
  @override
  State<SetupScreen> createState() => _SetupScreenState();
}

class _SetupScreenState extends State<SetupScreen> {
  int _dotCount = 3;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('反應速度遊戲')),
      body: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('玩法：看到圓點變成綠色，立刻點擊！\n共 10 輪，超時或點錯算失敗。'),
            const SizedBox(height: 32),
            const Text('選擇圓點數量（越多越難）：'),
            const SizedBox(height: 12),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [1, 3, 5, 8].map((n) {
                return ChoiceChip(
                  label: Text('$n 個'),
                  selected: _dotCount == n,
                  onSelected: (_) => setState(() => _dotCount = n),
                );
              }).toList(),
            ),
            const Spacer(),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed: () => widget.onStart(_dotCount),
                child: const Text('開始'),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ── 遊戲頁 ──
// 回合數由GameScreen內的_roundsDone管理，

class GameScreen extends StatefulWidget {
  final int dotCount;
  final int totalRounds;
  final void Function(int ms) onRoundDone;
  final VoidCallback onGameOver;

  const GameScreen({
    super.key,
    required this.dotCount,
    required this.totalRounds,
    required this.onRoundDone,
    required this.onGameOver,
  });

  @override
  State<GameScreen> createState() => _GameScreenState();
}

class _GameScreenState extends State<GameScreen> {
  final _rng = Random();
  List<Offset> _positions = [];
  int _targetIndex = -1;
  DateTime? _shownAt;
  bool _active = false;
  String _hint = '準備中…';
  int _roundsDone = 0; // 內部計算完成輪數

  Timer? _waitTimer;
  Timer? _timeoutTimer;

  static const int timeLimitMs = 1500;

  int get _currentRound => _roundsDone + 1;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) => _startRound());
  }

  @override
  void dispose() {
    _waitTimer?.cancel();
    _timeoutTimer?.cancel();
    super.dispose();
  }

  void _startRound() {
    setState(() {
      _targetIndex = -1;
      _positions = [];
      _active = false;
      _hint = '等待…';
    });

    final delay = 1000 + _rng.nextInt(2000);
    _waitTimer = Timer(Duration(milliseconds: delay), _showTarget);
  }

  void _showTarget() {
    if (!mounted) return;
    final size = MediaQuery.of(context).size;
    final areaH = size.height - 200.0;
    const r = 30.0;

    final positions = <Offset>[];
    for (int i = 0; i < widget.dotCount; i++) {
      Offset pos;
      int tries = 0;
      do {
        pos = Offset(
          r + _rng.nextDouble() * (size.width - r * 2 - 32),
          r + _rng.nextDouble() * (areaH - r * 2),
        );
        tries++;
      } while (
        tries < 100 &&
        positions.any((p) => (p - pos).distance < r * 2.5)
      );
      positions.add(pos);
    }

    setState(() {
      _positions = positions;
      _targetIndex = _rng.nextInt(widget.dotCount);
      _shownAt = DateTime.now();
      _active = true;
      _hint = '點擊綠色圓點！';
    });

    _timeoutTimer?.cancel();
    _timeoutTimer = Timer(
      const Duration(milliseconds: timeLimitMs),
      _onTimeout,
    );
  }

  void _onTap(int index) {
    if (!_active) return;
    _timeoutTimer?.cancel();
    _waitTimer?.cancel();
    final ms = DateTime.now().difference(_shownAt!).inMilliseconds;
    _endRound(index == _targetIndex ? ms : -1);
  }

  void _onTimeout() {
    if (!_active) return;
    _endRound(-1);
  }

  void _endRound(int ms) {
    setState(() {
      _active = false;
      _roundsDone++;
      _hint = ms >= 0 ? '✓ ${ms}ms' : '✗ 失敗';
    });

    widget.onRoundDone(ms);

    Future.delayed(const Duration(milliseconds: 800), () {
      if (!mounted) return;
      if (_roundsDone >= widget.totalRounds) {
        widget.onGameOver();
      } else {
        _startRound();
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    final size = MediaQuery.of(context).size;
    final areaH = size.height - 200.0;

    return Scaffold(
      appBar: AppBar(
        title: Text('第 $_currentRound / ${widget.totalRounds} 輪'),
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(12),
            child: Text(_hint, style: const TextStyle(fontSize: 18)),
          ),
          Container(
            width: double.infinity,
            height: areaH,
            color: Colors.grey.shade100,
            child: Stack(
              children: List.generate(_positions.length, (i) {
                final isTarget = i == _targetIndex;
                return Positioned(
                  left: _positions[i].dx - 30,
                  top: _positions[i].dy - 30,
                  child: GestureDetector(
                    onTap: () => _onTap(i),
                    child: Container(
                      width: 60,
                      height: 60,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: (_active && isTarget)
                            ? Colors.green
                            : Colors.blueGrey.shade300,
                      ),
                    ),
                  ),
                );
              }),
            ),
          ),
        ],
      ),
    );
  }
}

// ── 結果頁 ──

class ResultScreen extends StatelessWidget {
  final List<int> reactionTimes;
  final VoidCallback onRestart;

  const ResultScreen({
    super.key,
    required this.reactionTimes,
    required this.onRestart,
  });

  @override
  Widget build(BuildContext context) {
    final hits = reactionTimes.where((t) => t >= 0).toList();
    final avg = hits.isEmpty ? 0 : hits.reduce((a, b) => a + b) ~/ hits.length;
    final best = hits.isEmpty ? 0 : hits.reduce(min);

    return Scaffold(
      appBar: AppBar(title: const Text('結果')),
      body: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('命中：${hits.length} / ${reactionTimes.length}'),
            Text('平均反應時間：${avg}ms'),
            Text('最佳反應時間：${best}ms'),
            const Divider(height: 32),
            const Text('每輪詳情：'),
            const SizedBox(height: 8),
            ...reactionTimes.asMap().entries.map((e) {
              final t = e.value;
              return Text('第 ${e.key + 1} 輪：${t >= 0 ? "${t}ms" : "失敗"}');
            }),
            const Spacer(),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed: onRestart,
                child: const Text('再玩一次'),
              ),
            ),
          ],
        ),
      ),
    );
  }
}